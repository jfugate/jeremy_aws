#!/bin/bash
./scripts/s3_sync.sh -b jeremylab-us-east-1 -r development -p default -g us-east-1 -z true
#./scripts/s3_sync.sh -b rbn-ops-2016-us-west-2 -r development -p default -g us-west-2 -z true
